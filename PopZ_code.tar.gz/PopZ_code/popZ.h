#ifndef POPZ_H
#define POPZ_H

class popZ{
 public:
  
  popZ();

  void setParameters();

  void setLength(double);
  double getLength();

  void popZInit();
  void cellFixed();
  void cellGrowth(); 

  void popZSSA(double);
  void popZSSA(double, char[], double);

  void propensity_update();
  void population_updateInit(int);
  void population_update(int);
  void binLength_update(double);


  void setOverExpression();

  void setOriGeneOn();
  void setOriGeneOff();
  void setDupGeneOn();
  void setDupGeneOff();
  void setDupSwitch();
  

  int selectBin1st(int[], int);
  int selectBin2nd(int[], int[], double);
  int selectBinAuto(int[], int[], int[], double);
  int selectDiffusionR(int[], int, int);
  int selectDiffusionL(int[], int, int);
  
  void printPopulation(char[]);
  void printFirings(char[]);
  void printPropensity(char[]);


 private:
  const static int RULENUM=18;
  double a[RULENUM];
  double a0;
  int firings[RULENUM];
  
  //parameters of population
  const static int BINNUM=100;

  const static int POPZR=85;
  const static int POPZL=14;

  int popZm[BINNUM], mRNA[BINNUM], popZp[BINNUM];
  int Mtot, Ptot, mRNAtot;

  //parameters for cell length
  double length, h;
  double mu;

  //parameters for chemical dynamics
  //const static double conv = 0.03;
  double conv;

  int gene_ori, gene_dup;
  int popZ_ori, popZ_dup;

  double krna, drna;

  double k_sm, k_dm, k_dp;
  double k_dnv, k_auto, k_depol;

  double Dg, Dm, Dp, Drna;
};

#endif
