#include <cstdio>
using std::sprintf;

#include <cstring>
using std::strcpy; 
using std::strcat;

#include <cstdlib>
using std::system;
using std::srand;

#include <ctime>
using std::time;

#include <iostream>
using std::cout;
using std::endl;

#include "popZ.h"

int main(int argc, char* argv[]){

  //*************************************
  //Usage: kartik <outputDir>
  //*************************************
  cout<<"Usage: ./kartik [outputDir]"<<endl;
  char outDir[80];
  if(argc<2){
    cout<<"No outputDir given, use default: out_new "<<endl;
    strcpy(outDir, "out_new");
  }
  else{
    strcpy(outDir, argv[1]);
    cout<<"Result in directory "<<outDir<<endl;
  }

  //*************************************
  //make directory for output
  //mkdir outDir
  //************************************* 
  int stat;
  char mkoutDir[80];
  strcpy(mkoutDir, "mkdir -p ");
  strcat(mkoutDir, outDir);
  stat=system(mkoutDir);

  char mkstatdir[100];
  strcpy(mkstatdir, mkoutDir);
  strcat(mkstatdir, "/population");
  stat=system(mkstatdir);

  int realization=160;
  char seq[10];
  char popDist[80], fireDist[80];

  popZ pz;

  //****************************************
  //seed the random variable
  //****************************************
  srand(time(NULL));

  for(int real=150; real<realization; real++){
    sprintf(seq, "%d", real);
    cout<<"progress: "<<real<<"/"<<realization<<endl;
    
    //*******************************************
    //the file to keep the population trajectory 
    //*******************************************
    strcpy(popDist, outDir);
    strcat(popDist, "/population");
    strcat(popDist, "/trajectory");
    strcat(popDist, seq);
    strcat(popDist, ".txt");

    strcpy(fireDist, outDir);
    strcat(fireDist, "/population");
    strcat(fireDist, "/firings");
    strcat(fireDist, seq);
    strcat(fireDist, ".txt");

    //*****************************************
    //Start the simulation 
    //Run ssa and keep the trajectory
    //*****************************************
    
    //set initial condition
    pz.popZInit(); 

    //*********************************************
    //set Fixed model parameter
    //Run the simulation for fixed length
    //*********************************************
    pz.cellFixed(); 

    pz.setOriGeneOn(); //set Fixed model parameter
    pz.setDupGeneOff(); //set Fixed model parameter
    
    pz.popZSSA(250.0);

    //******************************************
    //***continue to run cell growth************
    //***First 50min, no dup convection
    //****************************************** 
    pz.cellGrowth(); 
    pz.popZSSA(30.0, popDist, 0.1);
  
    //******************************************
    //***With 2 popZsite *********************** 
    //******************************************

    //******************************************
    //Dup move to the other end
    //The mRNA was given only in the left end
    //******************************************
    pz.setDupGeneOn();

    //******************************************
    //The swith mode
    //******************************************
//    pz.setOriGeneOff();
//    pz.setDupSwitch();
//    pz.convectionOff();

    pz.popZSSA(120.0, popDist, 0.1);
  
    pz.printFirings(fireDist);

  }

}
