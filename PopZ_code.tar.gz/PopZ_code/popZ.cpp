#include <cstdlib>
using std::rand;

#include <iostream>
using std::cout;
using std::endl;
using std::cerr;

#include <cmath>
using std::log;

#include <fstream>
using std::ofstream;
using std::ios;

#include "popZ.h"

popZ::popZ(){ popZInit(); setParameters();}

void popZ::setParameters(){

  conv = 0.08;  krna=1.0; drna=0.20;//0.25;

  int scale = 800;
  k_sm=15.0;//30; .05*scale; 
  k_dm=0.05; k_dp=0.05;
  k_dnv=12.0; k_auto=12.0/(scale*scale); k_depol=0.1;

  Dg=0.01; Dm=10.0; Dp=0.001; Drna=0.025;

}

//****************************************
//Cell size growth
//***************************************
void popZ::binLength_update(double tau){
  length=length+length*mu*tau;
  h = length/BINNUM;
}

void popZ::setLength(double len){
  length=len;
  h=length/BINNUM;
}

double popZ::getLength(){ return length; }

void popZ::popZInit(){

  setLength(1.30);

  gene_ori =1; gene_dup = 0;
  popZ_ori=POPZR; popZ_dup=POPZR;
  for(int i=0; i<BINNUM; i++) mRNA[i]=0;
  for(int i=0; i<BINNUM; i++)popZm[i]=0; 
  for(int i=0; i<BINNUM; i++)popZp[i]=0;

  mRNAtot=0; Mtot=0; Ptot=0;

  a0=0.0;
  for(int i=0; i<RULENUM; i++)a[i]=0;
  for(int i=0; i<RULENUM; i++)firings[i]=0;
}

void popZ::cellFixed(){  mu=0.0; }
void popZ::cellGrowth(){ mu=0.005577; }

void popZ::setOriGeneOn(){ gene_ori = 1; popZ_ori = POPZR;}
void popZ::setOriGeneOff(){gene_ori = 0; }
void popZ::setDupGeneOn(){ gene_dup = 1; popZ_dup = POPZR;}
void popZ::setDupGeneOff(){gene_dup = 0; }
void popZ::setDupSwitch(){ gene_dup = 1; popZ_dup = POPZL; }

void popZ::setOverExpression(){
  gene_ori = gene_ori*2; gene_dup=gene_dup*2;
}

void popZ::popZSSA(double t){

  double timeTracker=0.0;
  
  int rint;
  double r1, r2;
  double tau;
  int ita;
  double sum, sum_a;
  
  for(int i=0; i<RULENUM; i++)firings[i]=0;

  propensity_update();

  a0=0.0;
  for(int i=0; i<RULENUM; i++)a0+=a[i];
  do{r1=1.0*rand()/RAND_MAX;}while(r1<=0 || r1>=1);
  tau=-1.0/a0*log(r1);

  timeTracker+=tau;

  while(timeTracker < t){

    r2 = 1.0*rand()/RAND_MAX;
    sum = r2*a0;

    ita=0;
    sum_a=a[ita];
    while(sum_a<sum){ita++; sum_a+=a[ita];}

    firings[ita]++;
    population_update(ita);
    binLength_update(tau);
    propensity_update();

    a0=0.0;
    for(int i=0; i<RULENUM; i++)a0+=a[i];
    do{r1=1.0*rand()/RAND_MAX;}while(r1<=0 || r1>=1);
    tau=-1.0/a0*log(r1);

    timeTracker+=tau;
    
  }
  

}


void popZ::popZSSA(double t, char fname[], double timeStep){

  double timeTracker=0.0;
  
  //********************************************
  //Keep the population at every min
  //********************************************
  double Timetag=timeStep;

  int rint;
  double r1, r2;
  double tau;
  int ita;
  double sum, sum_a;
  
  //**********************************************
  //Get ready to the SSA 
  //**********************************************
  for(int i=0; i<RULENUM; i++)firings[i]=0;

  propensity_update();

  a0=0.0;
  for(int i=0; i<RULENUM; i++)a0+=a[i];
  do{r1=1.0*rand()/RAND_MAX;}while(r1<=0 || r1>=1);
  
  tau=-1.0/a0*log(r1);

  timeTracker+=tau;

  while(timeTracker < t){

    //***************************************
    //Keep the population at every min
    //***************************************
    if(timeTracker > Timetag){
      printPopulation(fname);   Timetag += timeStep;
    }

    do{r2 = 1.0*rand()/RAND_MAX;}while(r2<=0 || r2>=1);
    sum = r2*a0;

    ita=0;
    sum_a=a[ita];
    while(sum_a<sum){ita++; sum_a+=a[ita];}

    firings[ita]++;
    population_update(ita);
    binLength_update(tau);
    propensity_update();

    a0=0.0;
    for(int i=0; i<RULENUM; i++)a0+=a[i];
    do{r1=1.0*rand()/RAND_MAX;}while(r1<=0 || r1>=1);
    
    tau=-1.0/a0*log(r1);
    
    timeTracker+=tau;
    
 }
  
  //*************************************
  //print out the population a the end
  //*************************************
  printPopulation(fname);

}

void popZ::propensity_update(){

  a[0] = conv/h*gene_dup;
  a[1] = Dg/(h*h)*gene_dup;
  a[2] = Dg/(h*h)*gene_dup;

  //kinetics for mRNA
  a[3] = krna*gene_ori;
  a[4] = krna*gene_dup;
  a[5] = drna*mRNAtot;

  a[6] = Drna/(h*h)*(mRNAtot-mRNA[BINNUM-1]);
  a[7] = Drna/(h*h)*(mRNAtot-mRNA[0]);

  //kinetics for M & P
  a[8] = k_sm*mRNAtot;
  a[9] = k_dm*Mtot;
  a[10] = Dm/(h*h)*(Mtot-popZm[BINNUM-1]);
  a[11] = Dm/(h*h)*(Mtot-popZm[0]);

  //M <--> P
  a[12] = k_dnv*Mtot;

  a[13] = 0;
  for(int i=0; i<BINNUM; i++)a[13]+=popZm[i]*popZp[i]*popZp[i];
  a[13] = a[13]*k_auto/(h*h);

  a[14] = k_depol*Ptot;
  a[15] = k_dp*Ptot;

  a[16] = Dp/(h*h)*(Ptot-popZp[BINNUM-1]);
  a[17] = Dp/(h*h)*(Ptot-popZp[0]);

}


void popZ::population_update(int ruleNo){

  int bin_ita;

  switch(ruleNo){

  case 0:
    if(popZ_dup>POPZL) popZ_dup -- ;
    break;  
  
  case 1:
    if(popZ_dup>POPZL && popZ_dup < POPZR) popZ_dup ++ ;
    break;  
  
  case 2:
    if(popZ_dup>POPZL) popZ_dup -- ;
    break;  
  
  case 3:
    mRNAtot++; mRNA[popZ_ori]++;
    break;
    
  case 4:
    mRNAtot++; mRNA[popZ_dup]++;
    break;
    
  case 5:
    bin_ita=selectBin1st(mRNA, mRNAtot);
    
    mRNAtot--; mRNA[bin_ita]--;
    break;
    
  case 6:
    bin_ita=selectDiffusionR(mRNA, BINNUM, mRNAtot);
    
    mRNA[bin_ita]--;
    mRNA[bin_ita+1]++;
    break;

  case 7:
    bin_ita=selectDiffusionL(mRNA, BINNUM, mRNAtot);

    mRNA[bin_ita]--;
    mRNA[bin_ita-1]++;
    break;

  case 8:
    bin_ita=selectBin1st(mRNA, mRNAtot);
    
    Mtot++;popZm[bin_ita]++;
    break;

  case 9:
    bin_ita=selectBin1st(popZm, Mtot);

    Mtot--;popZm[bin_ita]--;
    break;

  case 10:
    bin_ita=selectDiffusionR(popZm, BINNUM, Mtot);
    popZm[bin_ita]--;
    popZm[bin_ita+1]++;
    break;

  case 11:
    bin_ita=selectDiffusionL(popZm, BINNUM, Mtot);

    popZm[bin_ita]--;
    popZm[bin_ita-1]++;
    break;

  case 12:
    bin_ita=selectBin1st(popZm, Mtot);
    
    Mtot--;popZm[bin_ita]--;
    Ptot++;popZp[bin_ita]++;
    break;

  case 13://a[9]+=popZm[i/Mt]*popZp[i]*popZp[i]*k_auto/(lm*lp)
    bin_ita=selectBinAuto(popZm, popZp, popZp, a[13]*h*h/k_auto);

    Mtot--;popZm[bin_ita]--;
    Ptot++;popZp[bin_ita]++;
    break;
    
  case 14:
    bin_ita=selectBin1st(popZp, Ptot);

    Ptot--; popZp[bin_ita]--;
    Mtot++; popZm[bin_ita]++;
    break;

  case 15:
    bin_ita= selectBin1st(popZp, Ptot);
    
    Ptot--; popZp[bin_ita]--;
    break;
    
  case 16:
    bin_ita=selectDiffusionR(popZp, BINNUM, Ptot);
    
    popZp[bin_ita]--;
    popZp[bin_ita+1]++;
    break;

  case 17:
    bin_ita=selectDiffusionL(popZp, BINNUM, Ptot);

    popZp[bin_ita]--;
    popZp[bin_ita-1]++;
    break;
    
  default:
    cout<<"bin_ita="<<bin_ita<<" not found"<<endl;
    break;
  }

}



int popZ::selectBin1st(int population[], int totP){
  
  double r3; 
  do{ r3 = 1.0*rand()/RAND_MAX;}while(r3<=0 || r3 >=1);

  if(totP<0){
	cerr<<"total population cannot be negative"<<endl;
	exit(1);
  }
  double bin_ra0 = r3*totP;
  
  int b_ita=0;
  int bin_sum = population[b_ita];
  while(bin_sum<bin_ra0){b_ita++; bin_sum+=population[b_ita];}
  
  return b_ita;
}



//select the reaction bin of 2nd order reaction
//population 2 is the contianer of larger size
int popZ::selectBin2nd(int population1[], int population2[], double totp2){
  
  double r3; 
  do{ r3 = 1.0*rand()/RAND_MAX;}while(r3<=0 || r3 >=1);

  double bin_ra0 = r3*totp2;

  int b_ita=0;
  int bin_sum = population1[b_ita]*population2[b_ita];
  while(bin_sum<bin_ra0){
    b_ita++;
    bin_sum+=population1[b_ita]*population2[b_ita];
  }

  return b_ita;
}


//a[5]+=popZm[i/Mt]*popZp[i]*popZp[i]*k_auto/(lm*lp)
int popZ::selectBinAuto(int population1[], int population2[], int population3[], double totp3){

  double r3; 
  do{ r3 = 1.0*rand()/RAND_MAX;}while(r3<=0 || r3 >=1);

  double bin_ra0 = r3*totp3;
  
  int b_ita=0;
  int bin_sum = population1[b_ita]*population2[b_ita]*population3[b_ita];
  while(bin_sum<bin_ra0){
    b_ita++;
    bin_sum+=population1[b_ita]*population2[b_ita]*population3[b_ita];
  }

  return b_ita;
}

int popZ::selectDiffusionR(int population[], int NUM, int totP){

  double r3; 
  do{ r3 = 1.0*rand()/RAND_MAX;}while(r3<=0 || r3 >=1);
  
  if(totP<0){
	cerr<<"total population cannot be negative"<<endl;
	exit(1);
  }
  double bin_ra0 = r3*(totP-population[NUM-1]);

  int b_ita=NUM-2;
  int bin_sum = population[b_ita];
  while(bin_sum<bin_ra0){b_ita--; bin_sum+=population[b_ita];}
  
  return b_ita;
}



int popZ::selectDiffusionL(int population[], int NUM, int totP){

  double r3; 
  do{ r3 = 1.0*rand()/RAND_MAX;}while(r3<=0 || r3 >=1);
 
  if(totP<0){
	cerr<<"total population cannot be negative"<<endl;
	exit(1);
  }

   double bin_ra0 = r3*(totP-population[0]);

  int b_ita=NUM-1;
  int bin_sum = population[b_ita];
  while(bin_sum<bin_ra0){b_ita--; bin_sum+=population[b_ita];}

  return b_ita;

}

void popZ::printPropensity(char filename[]){

  ofstream ofile(filename, ios::out);

  for(int i=0; i<RULENUM; i++)ofile<<a[i]<<endl;

  ofile.close();
}


void popZ::printFirings(char filename[]){

  ofstream ofile(filename, ios::out);

  for(int i=0; i<RULENUM; i++)ofile<<firings[i]<<endl;

  ofile.close();
}


void popZ::printPopulation(char filename[]){

  ofstream ofile(filename, ios::out|ios::app);

  for(int i=0; i<BINNUM; i++)ofile<<mRNA[i]<<"\t";
  for(int i=0; i<BINNUM; i++)ofile<<popZm[i]<<"\t";
  for(int i=0; i<BINNUM; i++)ofile<<popZp[i]<<"\t";
  ofile<<popZ_ori<<"\t"<<popZ_dup<<'\t';
  ofile<<gene_ori<<"\t"<<gene_dup<<endl;


  ofile.close();

}
